<?php
$host = 'sql8.freesqldatabase.com';
$db = 'sql8745128';
$user = 'sql8745128'; // Change this if your MySQL username is different
$pass = 'dHKFWVRjYY'; // Add your password if you set one for MySQL

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>